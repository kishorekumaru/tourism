<?PHP
	//Database configuration file
	define('DB_NAME','harionne_glacier');
	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS','');
?>