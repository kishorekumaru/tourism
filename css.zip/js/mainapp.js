// JavaScript Document
var app = angular.module("glacierHolidays", []);




