<?PHP
	//Database configuration file
	define('DB_NAME','harionne_glacierholidays');
	define('DB_HOST','localhost');
	define('DB_USER','harionne_gholida');
	define('DB_PASS','GlacierHolidays!@#$');
?>