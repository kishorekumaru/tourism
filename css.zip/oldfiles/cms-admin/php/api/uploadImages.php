<?php

echo addslashes( "thumb". DIRECTORY_SEPARATOR . "BigImage.jpg");
?>